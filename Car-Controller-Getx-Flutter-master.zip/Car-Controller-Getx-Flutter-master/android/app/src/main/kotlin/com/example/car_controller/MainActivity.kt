package com.example.car_controller

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
